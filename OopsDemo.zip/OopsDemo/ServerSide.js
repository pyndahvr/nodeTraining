var  fs = require("fs");
console.log("Going to read directory");
fs.readdir(".",function (errs,files) {
    if(errs){
        return console.error(errs);
    }
    files.forEach(function(file){
        console.log(file);
    });
});