

    var mongoose = require('mongoose');
    var config = require('./config');
    mongoose.connect(config.url, config.mongodb, config.mongoport);
//mongoose.connect('mongodb://localhost:50000/accountsdb');
    var db = mongoose.connection;
    var schema = new mongoose.Schema(
        {
            id: Number,
            name: String,
            startDate: Date,
            balance: Number,
            type: String
        });

    CustomerModel = mongoose.model('customer', schema);
module.exports.getCustomerDatafromMongo = function () {
    db.once('open', function () {
        console.log("connected.....");
    });

    /*
    var customerData = new CustomerModel ({
        id:435679,
        name:"Anoop",
        startDate:new Date(),
        balance:435345,
        type:"savings"
    });
    customerData.save(function(err, customerData) {
        if (err) return console.error(err);
        console.log("saving......");
    });*/
    data = CustomerModel.find({}, function (err, res) {
        console.log("reaching...");
        console.log(err);
        console.log(res);
        return res;
    });
    console.log(data);
    return data;
}
/*result=module.exports.getCustomerDatafromMongo();
result.then(function (res) {
    console.log(res)
})*/