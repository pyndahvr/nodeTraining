exports.url="localhost"
exports.mongodb = "accountsdb"
exports.mongoport=50000