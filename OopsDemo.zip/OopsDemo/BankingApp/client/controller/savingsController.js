
savingsModule.controller('SavingsCtlr',['$scope',function($scope)
{
$scope.account={
    accountId:0,
    balance:456,
    type:'savings',
    startDate:new Date(2017,11,11)
}
$scope.accountSubmit=function () {
console.log($scope.account);
}
}]);
savingsModule.controller('CustomerCtrl',['$scope','$http',function ($scope,$http) {
$http({
    method:'GET',
    datatype:'json',
    headers:{
'Content-Type':'application/json'
    },
    url:'http://localhost:3000/getCustomers'
}).then(function(response){
    console.log(response.data);
    $scope.customerdata=response.data;
})
}]);
savingsModule.controller('CustomerCtrlMongo',['$scope','$http',function ($scope,$http) {
    $http({
        method:'GET',
        datatype:'json',
        headers:{
            'Content-Type':'application/json'
        },
        url:'http://localhost:3000/getCustomersfromMongo'
    }).then(function(response){
        console.log(response.data);
        $scope.customerdataMongo=response.data;
    })
}])