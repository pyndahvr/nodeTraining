var express        =         require("express");

var bodyParser     =         require("body-parser");

var mysql = require("mysql");

var app            =         express();

var connection = mysql.createConnection({
        connectionLimit : 100,
        hostname : 'localhost',
        user : 'root',
        password : 'rps@123',
        database : 'anz_financedb'
    }
)

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());

app.post('/login',function(req,res){
    // Website you wish to allow to connect

    res.setHeader('Access-Control-Allow-Origin', '*');
    // Request methods you wish to allow

    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    // Request headers you wish to allow

    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // Set to true if you need the website to include cookies in the requests sent

    // to the API (e.g. in case you use sessions)

    res.setHeader('Access-Control-Allow-Credentials', true);
    var user_name=req.body.username;

    var password=req.body.password;

    console.log("User name = "+user_name+", password is "+password);

    //console.log(req.body);

    res.end("done");
});

app.post('/registration',function(req,res){
    // Website you wish to allow to connect

    res.setHeader('Access-Control-Allow-Origin', '*');
    // Request methods you wish to allow

    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    // Request headers you wish to allow

    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // Set to true if you need the website to include cookies in the requests sent

    // to the API (e.g. in case you use sessions)

    res.setHeader('Access-Control-Allow-Credentials', true);
    var custId=req.body.custId;
    var custName=req.body.custname;
    var address=req.body.address;
    var mobileNo=req.body.mobile;
    console.log("CustomerId = "+custId+", Customer Name "+custName+", Address is "+address+", Mobile Number is "+mobileNo );

    connection.connect();

    var insertrecord = 'INSERT INTO customer (Customer_Id,Name,address,MobileNo) VALUES(?,?,?,?)';
    connection.query(insertrecord,[custId,custName,address,mobileNo],function (err, req) {
        if (!err)

            console.log('New Customer has been added');

        else

            console.log('Error while performing Query.:'+err);
    });
    connection.end();

    res.send("done");
});
app.listen(3000,function(){

    console.log("Started on PORT 3000");

});