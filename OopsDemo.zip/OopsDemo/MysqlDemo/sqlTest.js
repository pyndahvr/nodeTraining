var mysql = require("mysql");

var connection = mysql.createConnection({
        connectionLimit : 100,
        hostname : 'localhost',
        user : 'root',
        password : 'rps@123',
        database : 'anz_financedb'
}
)
connection.connect();

connection.query('SELECT * from customer', function(err, rows, fields) {

    if (!err)

        console.log('The solution is: ', rows);

    else

        console.log('Error while performing Query.:'+err);

});

var insertrecord = 'INSERT INTO customer (Customer_Id,Name,address,MobileNo) VALUES(?,?,?,?)';
connection.query(insertrecord,[999,'Person3','AP','987654235'],function (err, req) {
    if (!err)

        console.log('The solution is: ', req);

    else

        console.log('Error while performing Query.:'+err);
});
connection.end();