$(document).ready(function () {
    $("#submit").click(function () {
        custId=$("#customerId").val();
        custname=$("#name").val();
        add=$("#address").val();
        mobile=$("#phNo").val();
        alert(custId+custname+add+mobile);
        data={
            "custId":custId,
            "custname":custname,
            "address":add,
            "mobile":mobile
        };
        $.post("http://localhost:3000/registration",data, function(data){
            if(data==='done')
            {
                console.log("New Customer has been added");
            }
            console.log(data);
        });
    });
});
