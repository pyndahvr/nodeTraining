$(document).ready(function () {
    $("#submit").click(function () {
        user=$("#userName").val();
        pwd=$("#password").val();
        alert(user+pwd);
        data={
            "username":user,
            "password":pwd
        };
    $.post("http://localhost:3000/login",data, function(data){
        if(data==='done')
        {
            console.log("login success");
        }
        console.log(data);
    });
    });
});
