package com.anz.models;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Entity;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springmodules.validation.bean.conf.loader.annotation.handler.NotBlank;

@Entity
@Table(name="ANZ_Customer")
public class customer {
	@NotEmpty(message="First Name should not be null")
	@Size(min=5,max=25,message="First Name should be between 5 to 25")
	@Column(name="FirstName",nullable=false,length=25)
	private String firstName;
	@NotEmpty(message="Last Name should not be null")
	@Size(min=5,max=25,message="Last Name should be between 5 to 25")
	@Column(name="LastName",nullable=false,length=25)
	private String lastName;
	@NotEmpty(message="Address should not be null")
	@Size(min=50,max=125,message="Address should be between 50 to 125")
	@Column(name="Address",nullable=false,length=25)
	private String address;
	@NotEmpty(message="Email should not be null")
	@Email(message="Email format error")
	@Column(name="Email",nullable=false,length=25)
	private String email;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	

}
