package com.anz.banking.util;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.anz.banking.entities.branch;
import com.anz.banking.models.PrivilegedCustomer;
import com.anz.banking.models.customer;
import com.anz.banking.models.debitCard;
import com.anz.banking.models.transaction;

public class bankingApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource resource = new ClassPathResource("bankingContext.xml");
		BeanFactory ctx = new XmlBeanFactory(resource);
		PrivilegedCustomer obj = (PrivilegedCustomer) ctx.getBean("pcustomer");
		if(obj instanceof PrivilegedCustomer)
			System.out.println("Object created");
		System.out.println(obj.getCustomerId());
		for (debitCard dc: obj.getDebitCardList()){
			System.out.println(dc.getCardNo());
		}
		System.out.println("Relationship Manager No ------>"+obj.getRmContactNo());
		ApplicationContext actx = new ClassPathXmlApplicationContext("bankingContext.xml");
		transaction tnx = (transaction) actx.getBean("transaction");
		System.out.println("DebitCard No(1) ------>"+tnx.getDebitCard1().getCardNo());
		System.out.println("DebitCard No(2)------>"+tnx.getDebitCard2().getCardNo());
		branch branchObj = (branch) actx.getBean("branchInstance");
		
	}

}
