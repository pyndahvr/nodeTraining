package com.anz.banking.models;

import java.util.List;

public class customer {
	private int customerId;
	private String name;
	private int acctNo;
	private String address;
	private String email;
	private List<debitCard> debitCardList;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(int acctNo) {
		this.acctNo = acctNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<debitCard> getDebitCardList() {
		return debitCardList;
	}
	public void setDebitCardList(List<debitCard> debitCardList) {
		this.debitCardList = debitCardList;
	}
	
	
}
