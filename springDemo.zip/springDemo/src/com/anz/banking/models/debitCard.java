package com.anz.banking.models;

import java.util.Date;

public class debitCard {
	private String cardNo;
	private int debitLimit;
	private Date expriyDate;
	private int balance;
	private String cvvNo;
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public int getDebitLimit() {
		return debitLimit;
	}
	public void setDebitLimit(int debitLimit) {
		this.debitLimit = debitLimit;
	}
	public Date getExpriyDate() {
		return expriyDate;
	}
	public void setExpriyDate(Date expriyDate) {
		this.expriyDate = expriyDate;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getCvvNo() {
		return cvvNo;
	}
	public void setCvvNo(String cvvNo) {
		this.cvvNo = cvvNo;
	}
	
}
