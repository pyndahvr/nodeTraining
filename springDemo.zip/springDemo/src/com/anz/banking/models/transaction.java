package com.anz.banking.models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class transaction {
	private int transactionId;
	private int amount;
	@Autowired
	@Qualifier("dc1")
	private debitCard debitCard1;
	@Autowired
	@Qualifier("dc2")
	private debitCard debitCard2;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public debitCard getDebitCard1() {
		return debitCard1;
	}
	public void setDebitCard1(debitCard debitCard1) {
		this.debitCard1 = debitCard1;
	}
	public debitCard getDebitCard2() {
		return debitCard2;
	}
	public void setDebitCard2(debitCard debitCard2) {
		this.debitCard2 = debitCard2;
	}
	public transaction(int transactionId, int amount) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
	}

}
