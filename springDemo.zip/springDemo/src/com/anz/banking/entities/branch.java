package com.anz.banking.entities;

import org.springframework.stereotype.Component;

@Component(value="branchInstance")
public class branch {
	private String branchId;
	private String address;
	private String phNo;
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhNo() {
		return phNo;
	}
	public void setPhNo(String phNo) {
		this.phNo = phNo;
	}
	
}
